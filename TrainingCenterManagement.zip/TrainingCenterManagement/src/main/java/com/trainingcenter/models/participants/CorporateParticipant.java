package com.trainingcenter.models.participants;

import java.util.List;

/**
 * Corporate participant (company registering multiple employees).
 */
public class CorporateParticipant extends Participant {
    private String companyName;

    public CorporateParticipant(String id, String name, String email, List<String> prerequisitesCompleted, String companyName) {
        super(id, name, email, prerequisitesCompleted);
        this.companyName = companyName;
    }

    @Override
    public void register() {
        System.out.println("Registering corporate participant: " + getName() + " (" + companyName + ")");
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
