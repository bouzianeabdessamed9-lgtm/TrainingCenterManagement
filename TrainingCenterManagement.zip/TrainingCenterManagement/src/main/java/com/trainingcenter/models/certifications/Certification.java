package com.trainingcenter.models.certifications;

import java.time.LocalDate;

/**
 * Abstract class representing a certification that can be earned by participants.
 */
public abstract class Certification {
    private String id;
    private String certificateType;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private String trainingId;
    private String participantId;

    public Certification(String id, String certificateType, String trainingId, String participantId, int validityYears) {
        this.id = id;
        this.certificateType = certificateType;
        this.issueDate = LocalDate.now();
        this.expiryDate = this.issueDate.plusYears(validityYears);
        this.trainingId = trainingId;
        this.participantId = participantId;
    }

    /**
     * Checks if the certification is currently valid.
     * @return true if the certification is valid, false otherwise
     */
    public boolean isValid() {
        return LocalDate.now().isBefore(expiryDate) || LocalDate.now().isEqual(expiryDate);
    }

    /**
     * Abstract method to verify if a participant is eligible for this certification.
     * @param participantId The ID of the participant to check
     * @return true if eligible, false otherwise
     */
    public abstract boolean verifyEligibility(String participantId);

    // Getters and Setters
    public String getId() {
        return id;
    }

    public String getCertificateType() {
        return certificateType;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public String getTrainingId() {
        return trainingId;
    }

    public String getParticipantId() {
        return participantId;
    }

    @Override
    public String toString() {
        return String.format("%s Certificate [ID: %s, Issued: %s, Expires: %s]",
                certificateType, id, issueDate, expiryDate);
    }
}
