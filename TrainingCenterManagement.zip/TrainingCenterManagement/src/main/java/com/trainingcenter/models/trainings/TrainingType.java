package com.trainingcenter.models.trainings;

/**
 * Enum representing types of trainings.
 */
public enum TrainingType {
    ONLINE,
    SHORT_COURSE,
    WORKSHOP,
    ONSITE,
    HYBRID
}
