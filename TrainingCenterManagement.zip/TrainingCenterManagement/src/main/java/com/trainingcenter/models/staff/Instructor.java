package com.trainingcenter.models.staff;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Class representing an instructor who can teach training sessions.
 */
public class Instructor {
    private String id;
    private String name;
    private String specialty;
    private List<LocalDate> unavailableDates;
    private double evaluationScore;
    private List<String> certifications;

    public Instructor(String id, String name, String specialty) {
        this.id = id;
        this.name = name;
        this.specialty = specialty;
        this.unavailableDates = new ArrayList<>();
        this.certifications = new ArrayList<>();
        this.evaluationScore = 0.0;
    }

    public boolean isAvailable(LocalDate date) {
        return !unavailableDates.contains(date);
    }

    public void addUnavailableDate(LocalDate date) {
        if (!unavailableDates.contains(date)) {
            unavailableDates.add(date);
        }
    }

    public void removeUnavailableDate(LocalDate date) {
        unavailableDates.remove(date);
    }

    public void updateEvaluation(double score) {
        // Simple moving average of evaluation scores
        this.evaluationScore = (this.evaluationScore + score) / 2;
    }

    public void addCertification(String certification) {
        if (!certifications.contains(certification)) {
            certifications.add(certification);
        }
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public List<LocalDate> getUnavailableDates() {
        return new ArrayList<>(unavailableDates);
    }

    public double getEvaluationScore() {
        return evaluationScore;
    }

    public List<String> getCertifications() {
        return new ArrayList<>(certifications);
    }
}
