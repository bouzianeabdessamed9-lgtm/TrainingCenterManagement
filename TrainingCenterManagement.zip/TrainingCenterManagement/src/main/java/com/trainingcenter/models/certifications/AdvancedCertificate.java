package com.trainingcenter.models.certifications;

/**
 * Advanced certificate implementation with 2 years validity.
 */
public class AdvancedCertificate extends Certification {
    public AdvancedCertificate(String id, String trainingId, String participantId) {
        super(id, "Advanced", trainingId, participantId, 2);
    }

    @Override
    public boolean verifyEligibility(String participantId) {
        return participantId != null && !participantId.isEmpty();
    }
}
