package com.trainingcenter.models;

import com.trainingcenter.models.staff.Instructor;
import com.trainingcenter.models.trainings.Training;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a scheduled training session with participants, instructors, and room assignments.
 */
public class Session {
    private String id;
    private Training training;
    private Instructor instructor;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String room;
    private int maxCapacity;
    private List<String> participantIds;
    private boolean isCancelled;

    public Session(String id, Training training, Instructor instructor, 
                  LocalDateTime startTime, int durationHours, String room, int maxCapacity) {
        this.id = id;
        this.training = training;
        this.instructor = instructor;
        this.startTime = startTime;
        this.endTime = startTime.plusHours(durationHours);
        this.room = room;
        this.maxCapacity = maxCapacity;
        this.participantIds = new ArrayList<>();
        this.isCancelled = false;
    }

    /**
     * Registers a participant for this session if there's available capacity.
     * @param participantId The ID of the participant to register
     * @return true if registration was successful, false otherwise
     */
    public boolean registerParticipant(String participantId) {
        if (isFull() || isCancelled) {
            return false;
        }
        if (!participantIds.contains(participantId)) {
            participantIds.add(participantId);
            return true;
        }
        return false;
    }

    /**
     * Checks if the session is at full capacity.
     * @return true if the session is full, false otherwise
     */
    public boolean isFull() {
        return participantIds.size() >= maxCapacity;
    }

    /**
     * Cancels the session and notifies participants.
     */
    public void cancel() {
        this.isCancelled = true;
        // In a real implementation, we would notify all participants here
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public Training getTraining() {
        return training;
    }

    public Instructor getInstructor() {
        return instructor;
    }

    public void setInstructor(Instructor instructor) {
        this.instructor = instructor;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public int getCurrentEnrollment() {
        return participantIds.size();
    }

    public List<String> getParticipantIds() {
        return new ArrayList<>(participantIds);
    }

    public boolean isCancelled() {
        return isCancelled;
    }

    @Override
    public String toString() {
        return String.format("Session [%s] - %s - %s to %s - %s (%d/%d participants)",
                id, training.getTitle(), startTime, endTime, 
                isCancelled ? "CANCELLED" : "Active", 
                participantIds.size(), maxCapacity);
    }
}
