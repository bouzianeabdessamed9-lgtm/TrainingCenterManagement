package com.trainingcenter.models.certifications;

/**
 * Professional certificate implementation with 3 years validity.
 */
public class ProfessionalCertificate extends Certification {
    public ProfessionalCertificate(String id, String trainingId, String participantId) {
        super(id, "Professional", trainingId, participantId, 3);
    }

    @Override
    public boolean verifyEligibility(String participantId) {
        return participantId != null && !participantId.isEmpty();
    }
}
