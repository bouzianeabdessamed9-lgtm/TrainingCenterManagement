package com.trainingcenter.models.participants;

import java.util.List;

/**
 * Abstract class representing a training participant.
 */
public abstract class Participant {
    private String id;
    private String name;
    private String email;
    private List<String> prerequisitesCompleted;
    private List<String> registeredTrainings;

    public Participant(String id, String name, String email, List<String> prerequisitesCompleted) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.prerequisitesCompleted = prerequisitesCompleted;
        this.registeredTrainings = new java.util.ArrayList<>();
    }

    // Abstract method to be implemented by subclasses
    public abstract void register();
    
    public void updateInfo(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public List<String> getPrerequisitesCompleted() {
        return prerequisitesCompleted;
    }

    public void addPrerequisite(String prerequisite) {
        if (!prerequisitesCompleted.contains(prerequisite)) {
            prerequisitesCompleted.add(prerequisite);
        }
    }

    public List<String> getRegisteredTrainings() {
        return registeredTrainings;
    }

    public void enrollInTraining(String trainingId) {
        if (trainingId == null || trainingId.trim().isEmpty()) return;
        if (!registeredTrainings.contains(trainingId)) {
            registeredTrainings.add(trainingId);
        }
    }

    public void setPrerequisitesCompleted(List<String> prerequisitesCompleted) {
        this.prerequisitesCompleted = prerequisitesCompleted;
    }
}
