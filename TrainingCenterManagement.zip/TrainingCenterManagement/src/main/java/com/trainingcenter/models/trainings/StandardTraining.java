package com.trainingcenter.models.trainings;

/**
 * Concrete implementation of the Training class for standard training programs.
 */
public class StandardTraining extends Training {
    
    public StandardTraining(String title, String trainingId, int duration, double price, 
                          String prerequisites, String description) {
        super(title, trainingId, duration, price, prerequisites, description);
    }

    @Override
    public void displayDetails() {
        System.out.println("Training: " + getTitle() + " (ID: " + getTrainingId() + ")");
        System.out.println("Type: " + (getType() != null ? getType() : "N/A"));
        System.out.println("Duration: " + getDurationHours() + " hours");
        System.out.println("Price: $" + getPrice());
        System.out.println("Prerequisites: " + getPrerequisites());
        System.out.println("Description: " + getDescription());
    }

    @Override
    public boolean checkPrerequisites(java.util.List<String> participantSkills) {
        // Simple implementation - checks if all prerequisites are in participant's skills
        String[] requiredSkills = getPrerequisites().split(",\\s*");
        for (String skill : requiredSkills) {
            if (!participantSkills.contains(skill.trim())) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public int getDurationHours() {
        return super.getDurationHours();
    }
    
    @Override
    public void setDurationHours(int duration) {
        super.setDurationHours(duration);
    }
}
