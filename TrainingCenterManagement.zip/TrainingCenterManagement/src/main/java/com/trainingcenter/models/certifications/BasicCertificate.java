package com.trainingcenter.models.certifications;

/**
 * Basic certificate implementation with 1 year validity.
 */
public class BasicCertificate extends Certification {
    public BasicCertificate(String id, String trainingId, String participantId) {
        super(id, "Basic", trainingId, participantId, 1);
    }

    @Override
    public boolean verifyEligibility(String participantId) {
        // Minimal verification: non-null
        return participantId != null && !participantId.isEmpty();
    }
}
