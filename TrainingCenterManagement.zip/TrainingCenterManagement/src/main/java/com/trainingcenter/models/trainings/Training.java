package com.trainingcenter.models.trainings;

import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * Abstract class representing a training program.
 */
public abstract class Training {
    private String title;
    private String trainingId;
    private String domain;
    private int duration; // in hours
    private String prerequisites;
    private double price;
    private String description;
    private TrainingType type;

    /**
     * Constructor for creating a new Training.
     * 
     * @param title The title of the training
     * @param trainingId The unique identifier for the training
     * @param duration The duration in hours
     * @param price The price of the training
     * @param prerequisites Comma-separated list of prerequisites
     * @param description A description of the training
     */
    public Training(String title, String trainingId, int duration, double price, 
                   String prerequisites, String description) {
        this.title = title;
        this.trainingId = trainingId;
        this.duration = duration;
        this.price = price;
        this.prerequisites = prerequisites;
        this.description = description;
        this.type = null;
    }
    
    /**
     * Constructor for backward compatibility.
     */
    public Training(String title, String domain, int duration, List<String> prerequisites, double price) {
        this(title, "TEMP" + System.currentTimeMillis(), duration, price, 
             String.join(", ", prerequisites), "No description provided");
        this.domain = domain;
    }

    public TrainingType getType() {
        return type;
    }

    public void setType(TrainingType type) {
        this.type = type;
    }

    /**
     * Displays the details of the training.
     * To be implemented by concrete subclasses.
     */
    public abstract void displayDetails();

    /**
     * Checks if a participant has all required prerequisites.
     * 
     * @param participantSkills List of skills the participant has
     * @return true if participant has all prerequisites, false otherwise
     */
    public boolean checkPrerequisites(List<String> participantSkills) {
        if (prerequisites == null || prerequisites.trim().isEmpty()) {
            return true; // No prerequisites to check
        }
        
        String[] requiredSkills = prerequisites.split(",\\s*");
        for (String skill : requiredSkills) {
            if (!participantSkills.contains(skill.trim())) {
                return false;
            }
        }
        return true;
    }

    // Getters and Setters
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public int getDuration() {
        return duration;
    }
    
    public void setDuration(int duration) {
        this.duration = duration;
    }
    
    public int getDurationHours() {
        return getDuration();
    }
    
    public void setDurationHours(int duration) {
        setDuration(duration);
    }

    public String getTrainingId() {
        return trainingId;
    }
    
    public void setTrainingId(String trainingId) {
        this.trainingId = trainingId;
    }

    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }

    public String getPrerequisites() {
        return prerequisites;
    }
    
    public void setPrerequisites(String prerequisites) {
        this.prerequisites = prerequisites;
    }
}
