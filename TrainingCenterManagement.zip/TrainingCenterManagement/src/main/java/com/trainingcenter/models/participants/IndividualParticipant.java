package com.trainingcenter.models.participants;

import java.util.List;

/**
 * Individual (private) participant.
 */
public class IndividualParticipant extends Participant {
    private String phone;

    public IndividualParticipant(String id, String name, String email, List<String> prerequisitesCompleted, String phone) {
        super(id, name, email, prerequisitesCompleted);
        this.phone = phone;
    }

    @Override
    public void register() {
        System.out.println("Registering individual participant: " + getName());
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
