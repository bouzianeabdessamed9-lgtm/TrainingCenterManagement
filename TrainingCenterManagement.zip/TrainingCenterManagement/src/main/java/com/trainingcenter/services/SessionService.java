package com.trainingcenter.services;

import com.trainingcenter.models.Session;
import com.trainingcenter.models.staff.Instructor;
import com.trainingcenter.models.trainings.StandardTraining;
import com.trainingcenter.models.participants.Participant;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class SessionService {
    public static void manageSessions(Scanner scanner, List<Session> sessions, List<StandardTraining> trainings, List<Instructor> instructors, List<Participant> participants) {
        boolean inSessionMenu = true;
        while (inSessionMenu) {
            System.out.println("\n=== Session Scheduling ===");
            System.out.println("1. View All Scheduled Sessions");
            System.out.println("2. Schedule New Session");
            System.out.println("3. Update Existing Session");
            System.out.println("4. Cancel Session");
            System.out.println("5. View Session Details");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option (0-5): ");

            try {
                int sessionChoice = Integer.parseInt(scanner.nextLine());
                switch (sessionChoice) {
                    case 1:
                        System.out.println("\n--- All Scheduled Sessions ---");
                        if (sessions.isEmpty()) {
                            System.out.println("No sessions scheduled.");
                        } else {
                            for (int i = 0; i < sessions.size(); i++) {
                                System.out.printf("%d. %s%n", i + 1, sessions.get(i).toString());
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 2:
                        System.out.println("\n--- Schedule New Session ---");
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available. Add trainings first.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        if (instructors.isEmpty()) {
                            System.out.println("No instructors available. Add instructors first.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        System.out.println("Select a training:");
                        for (int i = 0; i < trainings.size(); i++) {
                            System.out.printf("%d. %s (ID: %s)%n", i + 1, trainings.get(i).getTitle(), trainings.get(i).getTrainingId());
                        }
                        System.out.print("Enter training number: ");
                        int trChoice = Integer.parseInt(scanner.nextLine()) - 1;
                        if (trChoice < 0 || trChoice >= trainings.size()) {
                            System.out.println("Invalid training selection.");
                            break;
                        }
                        StandardTraining selectedTraining = trainings.get(trChoice);
                        System.out.println("Select an instructor:");
                        for (int i = 0; i < instructors.size(); i++) {
                            System.out.printf("%d. %s (ID: %s)%n", i + 1, instructors.get(i).getName(), instructors.get(i).getId());
                        }
                        System.out.print("Enter instructor number: ");
                        int insChoice = Integer.parseInt(scanner.nextLine()) - 1;
                        if (insChoice < 0 || insChoice >= instructors.size()) {
                            System.out.println("Invalid instructor selection.");
                            break;
                        }
                        Instructor selectedInstructor = instructors.get(insChoice);
                        System.out.print("Enter session start (yyyy-MM-dd HH:mm): ");
                        String dtInput = scanner.nextLine();
                        LocalDateTime start;
                        try {
                            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                            start = LocalDateTime.parse(dtInput, fmt);
                        } catch (DateTimeParseException dte) {
                            System.out.println("Invalid date/time format.");
                            break;
                        }
                        System.out.print("Enter duration in hours (or press Enter for training default): ");
                        String durInput = scanner.nextLine();
                        int duration = selectedTraining.getDurationHours();
                        if (!durInput.isEmpty()) {
                            try { duration = Integer.parseInt(durInput); } catch (NumberFormatException nfe) { }
                        }
                        System.out.print("Enter room: ");
                        String room = scanner.nextLine();
                        System.out.print("Enter max capacity: ");
                        int maxCap = Integer.parseInt(scanner.nextLine());
                        String sid = "S" + (System.currentTimeMillis() % 100000);
                        sessions.add(new Session(sid, selectedTraining, selectedInstructor, start, duration, room, maxCap));
                        System.out.println("Session scheduled with ID: " + sid);
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 3:
                        System.out.println("\n--- Update Session ---");
                        if (sessions.isEmpty()) {
                            System.out.println("No sessions to update.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        for (int i = 0; i < sessions.size(); i++) {
                            System.out.printf("%d. %s%n", i+1, sessions.get(i).toString());
                        }
                        System.out.print("Enter session number to update: ");
                        int su = Integer.parseInt(scanner.nextLine()) - 1;
                        if (su < 0 || su >= sessions.size()) { System.out.println("Invalid selection."); break; }
                        Session sessToUpdate = sessions.get(su);
                        System.out.print("Enter new instructor ID (or press Enter to keep current): ");
                        String newInsId = scanner.nextLine();
                        if (!newInsId.isEmpty()) {
                            Instructor newIns = null;
                            for (Instructor ins : instructors) if (ins.getId().equalsIgnoreCase(newInsId)) { newIns = ins; break; }
                            if (newIns != null) sessToUpdate.setInstructor(newIns);
                            else System.out.println("Instructor ID not found; keeping current.");
                        }
                        System.out.print("Enter new room (or press Enter to keep current): ");
                        String newRoom = scanner.nextLine();
                        if (!newRoom.isEmpty()) sessToUpdate.setRoom(newRoom);
                        System.out.println("Session updated.");
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 4:
                        System.out.println("\n--- Cancel Session ---");
                        if (sessions.isEmpty()) {
                            System.out.println("No sessions to cancel.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        for (int i = 0; i < sessions.size(); i++) {
                            System.out.printf("%d. %s%n", i+1, sessions.get(i).toString());
                        }
                        System.out.print("Enter session number to cancel: ");
                        int sc = Integer.parseInt(scanner.nextLine()) - 1;
                        if (sc < 0 || sc >= sessions.size()) { System.out.println("Invalid selection."); break; }
                        sessions.get(sc).cancel();
                        System.out.println("Session cancelled.");
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 5:
                        System.out.println("\n--- Session Details ---");
                        if (sessions.isEmpty()) {
                            System.out.println("No sessions available.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        for (int i = 0; i < sessions.size(); i++) {
                            System.out.printf("%d. %s%n", i+1, sessions.get(i).toString());
                        }
                        System.out.print("Enter session number to view details: ");
                        int sv = Integer.parseInt(scanner.nextLine()) - 1;
                        if (sv < 0 || sv >= sessions.size()) { System.out.println("Invalid selection."); break; }
                        Session sdet = sessions.get(sv);
                        System.out.println(sdet.toString());
                        System.out.println("Training: " + sdet.getTraining().getTitle() + " (ID: " + sdet.getTraining().getTrainingId() + ")");
                        System.out.println("Instructor: " + (sdet.getInstructor() != null ? sdet.getInstructor().getName() : "TBD"));
                        System.out.println("Start: " + sdet.getStartTime());
                        System.out.println("End: " + sdet.getEndTime());
                        System.out.println("Room: " + sdet.getRoom());
                        System.out.println("Capacity: " + sdet.getCurrentEnrollment() + "/" + sdet.getMaxCapacity());
                        System.out.println("Participants:");
                        for (String pid : sdet.getParticipantIds()) {
                            String pname = pid;
                            for (Participant p : participants) if (p.getId().equalsIgnoreCase(pid)) { pname = p.getName(); break; }
                            System.out.println("- " + pname + " (" + pid + ")");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 0:
                        inSessionMenu = false;
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
    }
}
