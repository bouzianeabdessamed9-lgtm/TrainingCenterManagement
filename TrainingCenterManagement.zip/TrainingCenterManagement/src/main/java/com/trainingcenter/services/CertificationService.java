package com.trainingcenter.services;

import com.trainingcenter.models.certifications.Certification;
import com.trainingcenter.models.certifications.BasicCertificate;
import com.trainingcenter.models.certifications.AdvancedCertificate;
import com.trainingcenter.models.certifications.ProfessionalCertificate;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Simple in-memory service to issue and manage certifications.
 */
public class CertificationService {
    private final List<Certification> certificates = new ArrayList<>();
    private final AtomicInteger counter = new AtomicInteger((int) (System.currentTimeMillis() % 10000));

    public List<Certification> listCertificates() {
        return new ArrayList<>(certificates);
    }

    public Certification issueCertificate(String type, String trainingId, String participantId) {
        String id = generateId(type);
        Certification cert;
        switch ((type == null) ? "" : type.toLowerCase()) {
            case "basic":
                cert = new BasicCertificate(id, trainingId, participantId);
                break;
            case "advanced":
                cert = new AdvancedCertificate(id, trainingId, participantId);
                break;
            case "professional":
                cert = new ProfessionalCertificate(id, trainingId, participantId);
                break;
            default:
                // default to Basic
                cert = new BasicCertificate(id, trainingId, participantId);
                break;
        }
        certificates.add(cert);
        return cert;
    }

    public Certification findById(String id) {
        for (Certification c : certificates) {
            if (c.getId().equalsIgnoreCase(id)) return c;
        }
        return null;
    }

    private String generateId(String type) {
        String prefix = "CERT";
        if (type != null) {
            String t = type.toLowerCase();
            if (t.contains("prof")) prefix = "PROF";
            else if (t.contains("adv")) prefix = "ADV";
            else if (t.contains("basic")) prefix = "BSC";
        }
        int seq = counter.incrementAndGet();
        long ts = System.currentTimeMillis() % 100000;
        return String.format("%s-%05d-%05d", prefix, seq % 100000, ts);
    }
}
