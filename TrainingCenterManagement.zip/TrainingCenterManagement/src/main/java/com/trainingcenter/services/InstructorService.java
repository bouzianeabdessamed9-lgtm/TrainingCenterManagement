package com.trainingcenter.services;

import com.trainingcenter.models.staff.Instructor;
import java.util.List;
import java.util.Scanner;

public class InstructorService {
    public static void manageInstructors(Scanner scanner, List<Instructor> instructors) {
        boolean inInstructorMenu = true;

        while (inInstructorMenu) {
            System.out.println("\n=== Instructor Management ===");
            System.out.println("1. View All Instructors");
            System.out.println("2. Add New Instructor");
            System.out.println("3. Update Instructor Information");
            System.out.println("4. View Instructor Schedule");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option (0-4): ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        System.out.println("\n--- All Instructors ---");
                        if (instructors.isEmpty()) {
                            System.out.println("No instructors available.");
                        } else {
                            for (Instructor ins : instructors) {
                                System.out.printf("- %s (ID: %s, Specialization: %s)%n", ins.getName(), ins.getId(), ins.getSpecialty());
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 2:
                        System.out.println("\n--- Add New Instructor ---");
                        System.out.print("Enter instructor name: ");
                        String iname = scanner.nextLine();
                        System.out.print("Enter specialization: ");
                        String ispecialty = scanner.nextLine();
                        String iid = "I" + (2000 + (int)(Math.random() * 1000));
                        Instructor newInstructor = new Instructor(iid, iname, ispecialty);
                        instructors.add(newInstructor);
                        System.out.println("\nInstructor added successfully!");
                        System.out.println("Name: " + iname);
                        System.out.println("Specialization: " + ispecialty);
                        System.out.println("ID: " + iid);
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 3:
                        System.out.println("\n--- Update Instructor ---");
                        System.out.print("Enter instructor ID to update: ");
                        String updateId = scanner.nextLine();
                        Instructor toUpdate = null;
                        for (Instructor ins : instructors) {
                            if (ins.getId().equalsIgnoreCase(updateId)) { toUpdate = ins; break; }
                        }
                        if (toUpdate == null) {
                            System.out.println("Instructor not found.");
                        } else {
                            System.out.print("Enter new name (or press Enter to keep current): ");
                            String newName = scanner.nextLine();
                            System.out.print("Enter new specialization (or press Enter to keep current): ");
                            String newSpec = scanner.nextLine();
                            if (!newName.isEmpty()) toUpdate.setName(newName);
                            if (!newSpec.isEmpty()) toUpdate.setSpecialty(newSpec);
                            System.out.println("Instructor updated.");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 4:
                        System.out.println("\n--- Instructor Schedule ---");
                        System.out.print("Enter instructor ID: ");
                        String viewId = scanner.nextLine();
                        Instructor found = null;
                        for (Instructor ins : instructors) {
                            if (ins.getId().equalsIgnoreCase(viewId)) { found = ins; break; }
                        }
                        if (found == null) {
                            System.out.println("Instructor not found.");
                        } else {
                            System.out.println("\nSchedule for Instructor " + found.getName() + " (" + found.getId() + "):");
                            System.out.println("1. Java Fundamentals - Mon/Wed 10:00-12:00");
                            System.out.println("2. Advanced Java - Tue/Thu 14:00-16:00");
                            System.out.println("3. Office Hours - Fri 10:00-12:00");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 0:
                        inInstructorMenu = false;
                        break;

                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
    }
}
