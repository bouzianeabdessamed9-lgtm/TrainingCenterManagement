package com.trainingcenter.services;

import com.trainingcenter.models.participants.Participant;
import com.trainingcenter.models.participants.IndividualParticipant;
import com.trainingcenter.models.participants.CorporateParticipant;
import com.trainingcenter.models.trainings.StandardTraining;
import com.trainingcenter.models.Session;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ParticipantService {
    public static void manageParticipants(Scanner scanner, List<Participant> participants, List<StandardTraining> trainings, List<Session> sessions) {
        boolean inParticipantMenu = true;
        while (inParticipantMenu) {
            System.out.println("\n=== Participant Management ===");
            System.out.println("1. View All Participants");
            System.out.println("2. Register New Participant");
            System.out.println("3. Update Participant Information");
            System.out.println("4. View Participant Details");
            System.out.println("5. Enroll Participant in Training");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option (0-5): ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1:
                        System.out.println("\n--- All Participants ---");
                        if (participants.isEmpty()) {
                            System.out.println("No participants registered.");
                        } else {
                            for (Participant p : participants) {
                                System.out.printf("- %s (ID: %s, Email: %s)%n", p.getName(), p.getId(), p.getEmail());
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 2:
                        System.out.println("\n--- Register New Participant ---");
                        System.out.print("Is this an Individual (1) or Corporate (2)? Enter 1 or 2: ");
                        String typeChoice = scanner.nextLine();
                        System.out.print("Enter participant name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter email: ");
                        String email = scanner.nextLine();
                        String newId = "P" + (1000 + (int)(Math.random() * 9000));
                        if ("2".equals(typeChoice)) {
                            System.out.print("Enter company name: ");
                            String company = scanner.nextLine();
                            Participant cp = new CorporateParticipant(newId, name, email, new ArrayList<>(), company);
                            participants.add(cp);
                        } else {
                            System.out.print("Enter phone (optional): ");
                            String phone = scanner.nextLine();
                            Participant ip = new IndividualParticipant(newId, name, email, new ArrayList<>(), phone);
                            participants.add(ip);
                        }
                        System.out.println("\nParticipant registered successfully!");
                        System.out.println("Name: " + name);
                        System.out.println("Email: " + email);
                        System.out.println("ID: " + newId);
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 3:
                        System.out.println("\n--- Update Participant ---");
                        System.out.print("Enter participant ID to update: ");
                        String updateId = scanner.nextLine();
                        Participant toUpdate = null;
                        for (Participant p : participants) {
                            if (p.getId().equalsIgnoreCase(updateId)) { toUpdate = p; break; }
                        }
                        if (toUpdate == null) {
                            System.out.println("Participant not found.");
                        } else {
                            System.out.print("Enter new name (or press Enter to keep current): ");
                            String newName = scanner.nextLine();
                            System.out.print("Enter new email (or press Enter to keep current): ");
                            String newEmail = scanner.nextLine();
                            if (!newName.isEmpty()) {
                                toUpdate.updateInfo(newName, toUpdate.getEmail());
                            }
                            if (!newEmail.isEmpty()) {
                                toUpdate.updateInfo(toUpdate.getName(), newEmail);
                            }
                            System.out.println("Participant updated.");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 4:
                        System.out.println("\n--- Participant Details ---");
                        System.out.print("Enter participant ID to view details: ");
                        String viewId = scanner.nextLine();
                        Participant found = null;
                        for (Participant p : participants) {
                            if (p.getId().equalsIgnoreCase(viewId)) { found = p; break; }
                        }
                        if (found == null) {
                            System.out.println("Participant not found.");
                        } else {
                            System.out.println("\nParticipant Details:");
                            System.out.println("ID: " + found.getId());
                            System.out.println("Name: " + found.getName());
                            System.out.println("Email: " + found.getEmail());
                            System.out.println("Prerequisites completed: " + found.getPrerequisitesCompleted());
                            System.out.println("Registered trainings: " + (found.getRegisteredTrainings().isEmpty() ? "None" : found.getRegisteredTrainings()));
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 5:
                        System.out.println("\n--- Enroll Participant in Training ---");
                        if (participants.isEmpty()) {
                            System.out.println("No participants available. Register participants first.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        System.out.print("Enter participant ID: ");
                        String pid = scanner.nextLine();
                        Participant participantToEnroll = null;
                        for (Participant p : participants) {
                            if (p.getId().equalsIgnoreCase(pid)) { participantToEnroll = p; break; }
                        }
                        if (participantToEnroll == null) {
                            System.out.println("Participant not found.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available to enroll in.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        System.out.println("Available trainings:");
                        for (int i = 0; i < trainings.size(); i++) {
                            StandardTraining t = trainings.get(i);
                            System.out.printf("%d. %s (ID: %s)%n", i+1, t.getTitle(), t.getTrainingId());
                        }
                        System.out.print("Enter training number to enroll (or 0 to cancel): ");
                        try {
                            int tchoice = Integer.parseInt(scanner.nextLine()) - 1;
                            if (tchoice >= 0 && tchoice < trainings.size()) {
                                String tid = trainings.get(tchoice).getTrainingId();
                                participantToEnroll.enrollInTraining(tid);
                                System.out.println("Participant enrolled in " + trainings.get(tchoice).getTitle() + " (" + tid + ")");
                                List<Session> candidates = new ArrayList<>();
                                for (Session s : sessions) {
                                    if (s.getTraining() != null && s.getTraining().getTrainingId().equalsIgnoreCase(tid) && !s.isFull() && !s.isCancelled()) {
                                        candidates.add(s);
                                    }
                                }
                                if (candidates.isEmpty()) {
                                    System.out.println("No scheduled sessions available for this training.");
                                } else {
                                    System.out.println("Available scheduled sessions for this training:");
                                    for (int si = 0; si < candidates.size(); si++) {
                                        Session s = candidates.get(si);
                                        System.out.printf("%d. %s - %s (Room: %s) (%d/%d)%n", si+1, s.getId(), s.getStartTime(), s.getRoom(), s.getCurrentEnrollment(), s.getMaxCapacity());
                                    }
                                    System.out.print("Enter session number to register participant (or 0 to skip): ");
                                    try {
                                        int sc = Integer.parseInt(scanner.nextLine()) - 1;
                                        if (sc >= 0 && sc < candidates.size()) {
                                            boolean ok = candidates.get(sc).registerParticipant(participantToEnroll.getId());
                                            if (ok) System.out.println("Participant registered into session " + candidates.get(sc).getId());
                                            else System.out.println("Could not register participant into session (maybe full or already registered).");
                                        } else {
                                            System.out.println("Skipped session registration.");
                                        }
                                    } catch (NumberFormatException nfe2) {
                                        System.out.println("Invalid input; skipped session registration.");
                                    }
                                }
                            } else {
                                System.out.println("Cancelled or invalid selection.");
                            }
                        } catch (NumberFormatException nfe) {
                            System.out.println("Invalid input.");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 0:
                        inParticipantMenu = false;
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
    }
}
