package com.trainingcenter.services;

import com.trainingcenter.models.trainings.StandardTraining;
import com.trainingcenter.models.trainings.TrainingType;
import java.util.List;
import java.util.Scanner;

public class TrainingService {
    public static void manageTrainings(Scanner scanner, List<StandardTraining> trainings) {
        boolean inTrainingMenu = true;
        while (inTrainingMenu) {
            System.out.println("\n=== Training Management ===");
            System.out.println("1. View All Trainings");
            System.out.println("2. Add New Training");
            System.out.println("3. Update Existing Training");
            System.out.println("4. Remove Training");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option (0-4): ");

            try {
                int trainingChoice = Integer.parseInt(scanner.nextLine());
                switch (trainingChoice) {
                    case 1:
                        System.out.println("\n--- All Available Trainings ---");
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available yet.");
                        } else {
                            for (int i = 0; i < trainings.size(); i++) {
                                StandardTraining t = trainings.get(i);
                                System.out.printf("%d. %s (ID: %s, Duration: %d hours, Price: %.2f DA, Type: %s)%n",
                                    i + 1, t.getTitle(), t.getTrainingId(), t.getDurationHours(), t.getPrice(),
                                    (t.getType() != null ? t.getType() : "N/A"));
                                System.out.println("   Prerequisites: " + t.getPrerequisites());
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 2:
                        System.out.println("\n--- Add New Training ---");
                        try {
                            System.out.print("Enter training title: ");
                            String title = scanner.nextLine();
                            System.out.print("Enter training ID (e.g., JAV101): ");
                            String trainingId = scanner.nextLine();
                            System.out.print("Enter duration in hours: ");
                            int duration = Integer.parseInt(scanner.nextLine());
                            System.out.print("Enter price: ");
                            double price = Double.parseDouble(scanner.nextLine());
                            System.out.print("Enter prerequisites: ");
                            String prerequisites = scanner.nextLine();
                            System.out.print("Enter description: ");
                            String description = scanner.nextLine();
                            System.out.println("Select training type:");
                            System.out.println("1. ONLINE");
                            System.out.println("2. SHORT_COURSE");
                            System.out.println("3. WORKSHOP");
                            System.out.println("4. ONSITE");
                            System.out.println("5. HYBRID");
                            System.out.print("Enter choice (1-5), or press Enter for none: ");
                            String typeInput = scanner.nextLine();
                            TrainingType chosenType = null;
                            try {
                                if (!typeInput.isEmpty()) {
                                    int typeChoice = Integer.parseInt(typeInput);
                                    switch (typeChoice) {
                                        case 1:
                                            chosenType = TrainingType.ONLINE;
                                            break;
                                        case 2:
                                            chosenType = TrainingType.SHORT_COURSE;
                                            break;
                                        case 3:
                                            chosenType = TrainingType.WORKSHOP;
                                            break;
                                        case 4:
                                            chosenType = TrainingType.ONSITE;
                                            break;
                                        case 5:
                                            chosenType = TrainingType.HYBRID;
                                            break;
                                        default:
                                            chosenType = null;
                                            break;
                                    }
                                }
                            } catch (NumberFormatException nfe) {
                                chosenType = null;
                            }

                            StandardTraining newTraining = new StandardTraining(title, trainingId, duration, price, prerequisites, description);
                            newTraining.setType(chosenType);
                            trainings.add(newTraining);
                            System.out.println("\nTraining added successfully!");
                            System.out.println("Title: " + newTraining.getTitle());
                            System.out.println("ID: " + newTraining.getTrainingId());
                            System.out.println("Duration: " + newTraining.getDurationHours() + " hours");
                            System.out.println("Price: " + String.format("%.2f", newTraining.getPrice()) + " DA");
                        } catch (NumberFormatException e) {
                            System.out.println("\nInvalid number format. Please try again.");
                        } catch (Exception e) {
                            System.out.println("\nError adding training: " + e.getMessage());
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 3:
                        System.out.println("\n--- Update Training ---");
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available to update.");
                        } else {
                            System.out.println("Select training to update:");
                            for (int i = 0; i < trainings.size(); i++) {
                                System.out.printf("%d. %s (ID: %s)%n", i + 1, trainings.get(i).getTitle(), trainings.get(i).getTrainingId());
                            }
                            System.out.print("\nEnter training number to update (or 0 to cancel): ");
                            int updateChoice = Integer.parseInt(scanner.nextLine()) - 1;
                            if (updateChoice >= 0 && updateChoice < trainings.size()) {
                                StandardTraining trainingToUpdate = trainings.get(updateChoice);
                                System.out.println("\nUpdating: " + trainingToUpdate.getTitle() + " (ID: " + trainingToUpdate.getTrainingId() + ")");
                                System.out.print("Enter new title (or press Enter to keep current): ");
                                String newTitle = scanner.nextLine();
                                if (!newTitle.isEmpty()) {
                                    trainingToUpdate.setTitle(newTitle);
                                }
                                System.out.print("Enter new duration in hours (or press Enter to keep current): ");
                                String durationInput = scanner.nextLine();
                                if (!durationInput.isEmpty()) {
                                    trainingToUpdate.setDurationHours(Integer.parseInt(durationInput));
                                }
                                System.out.print("Enter new price (or press Enter to keep current): ");
                                String priceInput = scanner.nextLine();
                                if (!priceInput.isEmpty()) {
                                    trainingToUpdate.setPrice(Double.parseDouble(priceInput));
                                }
                                System.out.println("\nTraining updated successfully!");
                            } else if (updateChoice != -1) {
                                System.out.println("Invalid selection.");
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 4:
                        System.out.println("\n--- Remove Training ---");
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available to remove.");
                        } else {
                            System.out.println("Select training to remove:");
                            for (int i = 0; i < trainings.size(); i++) {
                                System.out.printf("%d. %s (ID: %s)%n", i + 1, trainings.get(i).getTitle(), trainings.get(i).getTrainingId());
                            }
                            System.out.print("\nEnter training number to remove (or 0 to cancel): ");
                            int removeChoice = Integer.parseInt(scanner.nextLine()) - 1;
                            if (removeChoice >= 0 && removeChoice < trainings.size()) {
                                StandardTraining removed = trainings.remove(removeChoice);
                                System.out.println("\nRemoved: " + removed.getTitle() + " (ID: " + removed.getTrainingId() + ")");
                            } else if (removeChoice != -1) {
                                System.out.println("Invalid selection.");
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 0:
                        inTrainingMenu = false;
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
    }
}
