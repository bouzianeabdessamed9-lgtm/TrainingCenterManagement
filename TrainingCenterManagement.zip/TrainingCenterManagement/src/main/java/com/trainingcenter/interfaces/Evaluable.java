package com.trainingcenter.interfaces;

/**
 * Interface for evaluating participants or sessions.
 */
public interface Evaluable {
    void recordEvaluation(String participantId, double score);
}
