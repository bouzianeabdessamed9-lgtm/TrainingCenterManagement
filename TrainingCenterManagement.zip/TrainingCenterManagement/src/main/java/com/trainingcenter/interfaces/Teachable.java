package com.trainingcenter.interfaces;

/**
 * Interface for entities that can be taught or can deliver a training.
 */
public interface Teachable {
    boolean canBeDelivered();
    String getDeliveryMethod();
}
