package com.trainingcenter.interfaces;

/**
 * Interface for entities that can be certified.
 */
public interface Certifiable {
    boolean isEligibleForCertification(String participantId);
    String getCertificationType();
}
