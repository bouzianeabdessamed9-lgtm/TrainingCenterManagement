package com.trainingcenter;

import com.trainingcenter.models.trainings.StandardTraining;
import com.trainingcenter.models.trainings.TrainingType;
import com.trainingcenter.models.participants.Participant;
import com.trainingcenter.models.participants.IndividualParticipant;
import com.trainingcenter.models.participants.CorporateParticipant;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import com.trainingcenter.services.CertificationService;
import com.trainingcenter.models.certifications.Certification;
import com.trainingcenter.models.staff.Instructor;
import com.trainingcenter.models.Session;
import com.trainingcenter.services.SessionService;

/**
 * Main class for the Training Center Management System.
 * This serves as the entry point for the application.
 */
public class Main {
    // List to store all trainings
    private static List<StandardTraining> trainings = new ArrayList<>();
    // List to store participants
    private static List<Participant> participants = new ArrayList<>();
    // List to store instructors
    private static List<Instructor> instructors = new ArrayList<>();
    // List to store scheduled sessions
    private static List<Session> sessions = new ArrayList<>();
    // Certification service
    private static CertificationService certificationService = new CertificationService();
    
    // Static initializer to add some sample data
    static {
        try {
            // Add sample trainings
            trainings.add(new StandardTraining("Java Programming", "JAV101", 40, 999.99, "Basic programming knowledge", "Introduction to Java programming"));
            trainings.add(new StandardTraining("Web Development", "WEB201", 30, 799.99, "HTML/CSS basics", "Full-stack web development"));
            trainings.add(new StandardTraining("Database Design", "DB301", 35, 899.99, "Basic SQL knowledge", "Database design and optimization"));
            // Add a couple of sample participants
            participants.add(new IndividualParticipant("P1001", "John Doe", "john@example.com", new ArrayList<>(), "+123456789"));
            participants.add(new IndividualParticipant("P1002", "Jane Smith", "jane@example.com", new ArrayList<>(), "+987654321"));
            // Add sample instructors
            instructors.add(new Instructor("I2001", "Dr. Sarah Johnson", "Java"));
            instructors.add(new Instructor("I2002", "Prof. David Wilson", "Web Dev"));
            instructors.add(new Instructor("I2003", "Dr. Emily Brown", "Database"));
            // Add sample sessions (if trainings and instructors available)
            try {
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                if (!trainings.isEmpty() && instructors.size() >= 2) {
                    LocalDateTime t1 = LocalDateTime.now().plusDays(7).withHour(9).withMinute(0);
                    LocalDateTime t2 = LocalDateTime.now().plusDays(14).withHour(13).withMinute(30);
                    sessions.add(new Session("S" + (System.currentTimeMillis() % 100000), trainings.get(0), instructors.get(0), t1, trainings.get(0).getDurationHours(), "Room A", 20));
                    sessions.add(new Session("S" + ((System.currentTimeMillis()+1) % 100000), trainings.get(1), instructors.get(1), t2, trainings.get(1).getDurationHours(), "Room B", 25));
                }
            } catch (Exception ex) {
                // ignore sample session creation errors
            }
        } catch (Exception e) {
            System.out.println("Error initializing sample data: " + e.getMessage());
        }
    }
    
    /**
     * Main method - entry point of the application
     */
    public static void main(String[] args) {
        System.out.println("=== Training Center Management System ===");
        System.out.println("Initializing system...\n");
        
        // Initialize scanner for user input
        Scanner scanner = new Scanner(System.in);
        
        // Main menu loop
        boolean running = true;
        while (running) {
            displayWelcomeMessage();
            System.out.print("\nEnter your choice (0-5): ");
            
            try {
                int choice = Integer.parseInt(scanner.nextLine());
                
                switch (choice) {
                    case 1:
                        manageTrainings(scanner);
                        break;
                    case 2:
                        manageParticipants(scanner);
                        break;
                    case 3:
                        manageInstructors(scanner);
                        break;
                    case 4:
                        scheduleSessions(scanner);
                        break;
                    case 5:
                        manageCertifications(scanner);
                        break;
                    case 0:
                        System.out.println("\nExiting the system. Goodbye!");
                        running = false;
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
        
        scanner.close();
    }
    
    private static void displayWelcomeMessage() {
        System.out.println("\nWelcome to the Training Center Management System");
        System.out.println("--------------------------------------------");
        System.out.println("Please select an option:");
        System.out.println("1. Manage Trainings");
        System.out.println("2. Manage Participants");
        System.out.println("3. Manage Instructors");
        System.out.println("4. Schedule Sessions");
        System.out.println("5. Manage Certifications");
        System.out.println("0. Exit");
    }
    
    private static void manageTrainings(Scanner scanner) {
        boolean inTrainingMenu = true;
        
        while (inTrainingMenu) {
            System.out.println("\n=== Training Management ===");
            System.out.println("1. View All Trainings");
            System.out.println("2. Add New Training");
            System.out.println("3. Update Existing Training");
            System.out.println("4. Remove Training");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option (0-4): ");
            
            try {
                int trainingChoice = Integer.parseInt(scanner.nextLine());
                
                switch (trainingChoice) {
                    case 1:
                        // View all trainings
                        System.out.println("\n--- All Available Trainings ---");
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available yet.");
                        } else {
                            for (int i = 0; i < trainings.size(); i++) {
                                StandardTraining t = trainings.get(i);
                                System.out.printf("%d. %s (ID: %s, Duration: %d hours, Price: $%.2f, Type: %s)%n", 
                                    i + 1, t.getTitle(), t.getTrainingId(), t.getDurationHours(), t.getPrice(),
                                    (t.getType() != null ? t.getType() : "N/A"));
                                System.out.println("   Prerequisites: " + t.getPrerequisites());
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                        
                    case 2:
                        // Add new training
                        System.out.println("\n--- Add New Training ---");
                        try {
                            System.out.print("Enter training title: ");
                            String title = scanner.nextLine();
                            
                            System.out.print("Enter training ID (e.g., JAV101): ");
                            String trainingId = scanner.nextLine();
                            
                            System.out.print("Enter duration in hours: ");
                            int duration = Integer.parseInt(scanner.nextLine());
                            
                            System.out.print("Enter price: ");
                            double price = Double.parseDouble(scanner.nextLine());
                            
                            System.out.print("Enter prerequisites: ");
                            String prerequisites = scanner.nextLine();
                            
                            System.out.print("Enter description: ");
                            String description = scanner.nextLine();
                            
                            // Prompt for training type
                            System.out.println("Select training type:");
                            System.out.println("1. ONLINE");
                            System.out.println("2. SHORT_COURSE");
                            System.out.println("3. WORKSHOP");
                            System.out.println("4. ONSITE");
                            System.out.println("5. HYBRID");
                            System.out.print("Enter choice (1-5), or press Enter for none: ");
                            String typeInput = scanner.nextLine();
                            TrainingType chosenType = null;
                            try {
                                if (!typeInput.isEmpty()) {
                                    int typeChoice = Integer.parseInt(typeInput);
                                    switch (typeChoice) {
                                        case 1: chosenType = TrainingType.ONLINE; break;
                                        case 2: chosenType = TrainingType.SHORT_COURSE; break;
                                        case 3: chosenType = TrainingType.WORKSHOP; break;
                                        case 4: chosenType = TrainingType.ONSITE; break;
                                        case 5: chosenType = TrainingType.HYBRID; break;
                                        default: chosenType = null; break;
                                    }
                                }
                            } catch (NumberFormatException nfe) {
                                chosenType = null;
                            }

                            // Create and add new training
                            StandardTraining newTraining = new StandardTraining(title, trainingId, duration, price, prerequisites, description);
                            newTraining.setType(chosenType);
                            trainings.add(newTraining);
                            
                            System.out.println("\nTraining added successfully!");
                            System.out.println("Title: " + newTraining.getTitle());
                            System.out.println("ID: " + newTraining.getTrainingId());
                            System.out.println("Duration: " + newTraining.getDurationHours() + " hours");
                            System.out.println("Price: $" + String.format("%.2f", newTraining.getPrice()));
                            
                        } catch (NumberFormatException e) {
                            System.out.println("\nInvalid number format. Please try again.");
                        } catch (Exception e) {
                            System.out.println("\nError adding training: " + e.getMessage());
                        }
                        
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                        
                    case 3:
                        // Update existing training
                        System.out.println("\n--- Update Training ---");
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available to update.");
                        } else {
                            System.out.println("Select training to update:");
                            for (int i = 0; i < trainings.size(); i++) {
                                System.out.printf("%d. %s (ID: %s)%n", i + 1, 
                                    trainings.get(i).getTitle(), trainings.get(i).getTrainingId());
                            }
                            System.out.print("\nEnter training number to update (or 0 to cancel): ");
                            int updateChoice = Integer.parseInt(scanner.nextLine()) - 1;
                            
                            if (updateChoice >= 0 && updateChoice < trainings.size()) {
                                StandardTraining trainingToUpdate = trainings.get(updateChoice);
                                System.out.println("\nUpdating: " + trainingToUpdate.getTitle() + " (ID: " + trainingToUpdate.getTrainingId() + ")");
                                
                                System.out.print("Enter new title (or press Enter to keep current): ");
                                String newTitle = scanner.nextLine();
                                if (!newTitle.isEmpty()) {
                                    trainingToUpdate.setTitle(newTitle);
                                }
                                
                                System.out.print("Enter new duration in hours (or press Enter to keep current): ");
                                String durationInput = scanner.nextLine();
                                if (!durationInput.isEmpty()) {
                                    trainingToUpdate.setDurationHours(Integer.parseInt(durationInput));
                                }
                                
                                System.out.print("Enter new price (or press Enter to keep current): ");
                                String priceInput = scanner.nextLine();
                                if (!priceInput.isEmpty()) {
                                    trainingToUpdate.setPrice(Double.parseDouble(priceInput));
                                }
                                
                                System.out.println("\nTraining updated successfully!");
                            } else if (updateChoice != -1) {
                                System.out.println("Invalid selection.");
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                        
                    case 4:
                        // Remove training
                        System.out.println("\n--- Remove Training ---");
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available to remove.");
                        } else {
                            System.out.println("Select training to remove:");
                            for (int i = 0; i < trainings.size(); i++) {
                                System.out.printf("%d. %s (ID: %s)%n", i + 1, 
                                    trainings.get(i).getTitle(), trainings.get(i).getTrainingId());
                            }
                            System.out.print("\nEnter training number to remove (or 0 to cancel): ");
                            int removeChoice = Integer.parseInt(scanner.nextLine()) - 1;
                            
                            if (removeChoice >= 0 && removeChoice < trainings.size()) {
                                StandardTraining removed = trainings.remove(removeChoice);
                                System.out.println("\nRemoved: " + removed.getTitle() + " (ID: " + removed.getTrainingId() + ")");
                            } else if (removeChoice != -1) {
                                System.out.println("Invalid selection.");
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                        
                    case 0:
                        // Return to main menu
                        inTrainingMenu = false;
                        break;
                        
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
    }
    
    private static void manageParticipants(Scanner scanner) {
        boolean inParticipantMenu = true;

        while (inParticipantMenu) {
            System.out.println("\n=== Participant Management ===");
            System.out.println("1. View All Participants");
            System.out.println("2. Register New Participant");
            System.out.println("3. Update Participant Information");
            System.out.println("4. View Participant Details");
            System.out.println("5. Enroll Participant in Training");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option (0-5): ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        System.out.println("\n--- All Participants ---");
                        if (participants.isEmpty()) {
                            System.out.println("No participants registered.");
                        } else {
                            for (Participant p : participants) {
                                System.out.printf("- %s (ID: %s, Email: %s)%n", p.getName(), p.getId(), p.getEmail());
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 2:
                        System.out.println("\n--- Register New Participant ---");
                        System.out.print("Is this an Individual (1) or Corporate (2)? Enter 1 or 2: ");
                        String typeChoice = scanner.nextLine();
                        System.out.print("Enter participant name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter email: ");
                        String email = scanner.nextLine();
                        String newId = "P" + (1000 + (int)(Math.random() * 9000));
                        if ("2".equals(typeChoice)) {
                            System.out.print("Enter company name: ");
                            String company = scanner.nextLine();
                            Participant cp = new CorporateParticipant(newId, name, email, new ArrayList<>(), company);
                            participants.add(cp);
                        } else {
                            System.out.print("Enter phone (optional): ");
                            String phone = scanner.nextLine();
                            Participant ip = new IndividualParticipant(newId, name, email, new ArrayList<>(), phone);
                            participants.add(ip);
                        }
                        System.out.println("\nParticipant registered successfully!");
                        System.out.println("Name: " + name);
                        System.out.println("Email: " + email);
                        System.out.println("ID: " + newId);
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 3:
                        System.out.println("\n--- Update Participant ---");
                        System.out.print("Enter participant ID to update: ");
                        String updateId = scanner.nextLine();
                        Participant toUpdate = null;
                        for (Participant p : participants) {
                            if (p.getId().equalsIgnoreCase(updateId)) {
                                toUpdate = p;
                                break;
                            }
                        }
                        if (toUpdate == null) {
                            System.out.println("Participant not found.");
                        } else {
                            System.out.print("Enter new name (or press Enter to keep current): ");
                            String newName = scanner.nextLine();
                            System.out.print("Enter new email (or press Enter to keep current): ");
                            String newEmail = scanner.nextLine();
                            if (!newName.isEmpty()) {
                                toUpdate.updateInfo(newName, toUpdate.getEmail());
                            }
                            if (!newEmail.isEmpty()) {
                                toUpdate.updateInfo(toUpdate.getName(), newEmail);
                            }
                            System.out.println("Participant updated.");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 4:
                        System.out.println("\n--- Participant Details ---");
                        System.out.print("Enter participant ID to view details: ");
                        String viewId = scanner.nextLine();
                        Participant found = null;
                        for (Participant p : participants) {
                            if (p.getId().equalsIgnoreCase(viewId)) {
                                found = p;
                                break;
                            }
                        }
                        if (found == null) {
                            System.out.println("Participant not found.");
                        } else {
                            System.out.println("\nParticipant Details:");
                            System.out.println("ID: " + found.getId());
                            System.out.println("Name: " + found.getName());
                            System.out.println("Email: " + found.getEmail());
                            System.out.println("Prerequisites completed: " + found.getPrerequisitesCompleted());
                            System.out.println("Registered trainings: " + (found.getRegisteredTrainings().isEmpty() ? "None" : found.getRegisteredTrainings()));
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 5:
                        System.out.println("\n--- Enroll Participant in Training ---");
                        if (participants.isEmpty()) {
                            System.out.println("No participants available. Register participants first.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        System.out.print("Enter participant ID: ");
                        String pid = scanner.nextLine();
                        Participant participantToEnroll = null;
                        for (Participant p : participants) {
                            if (p.getId().equalsIgnoreCase(pid)) { participantToEnroll = p; break; }
                        }
                        if (participantToEnroll == null) {
                            System.out.println("Participant not found.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        if (trainings.isEmpty()) {
                            System.out.println("No trainings available to enroll in.");
                            System.out.println("Press Enter to continue...");
                            scanner.nextLine();
                            break;
                        }
                        System.out.println("Available trainings:");
                        for (int i = 0; i < trainings.size(); i++) {
                            StandardTraining t = trainings.get(i);
                            System.out.printf("%d. %s (ID: %s)%n", i+1, t.getTitle(), t.getTrainingId());
                        }
                        System.out.print("Enter training number to enroll (or 0 to cancel): ");
                        try {
                            int tchoice = Integer.parseInt(scanner.nextLine()) - 1;
                            if (tchoice >= 0 && tchoice < trainings.size()) {
                                String tid = trainings.get(tchoice).getTrainingId();
                                participantToEnroll.enrollInTraining(tid);
                                System.out.println("Participant enrolled in " + trainings.get(tchoice).getTitle() + " (" + tid + ")");
                                // Offer to register participant into a scheduled session for this training
                                List<Session> candidates = new ArrayList<>();
                                for (Session s : sessions) {
                                    if (s.getTraining() != null && s.getTraining().getTrainingId().equalsIgnoreCase(tid) && !s.isFull() && !s.isCancelled()) {
                                        candidates.add(s);
                                    }
                                }
                                if (candidates.isEmpty()) {
                                    System.out.println("No scheduled sessions available for this training.");
                                } else {
                                    System.out.println("Available scheduled sessions for this training:");
                                    for (int si = 0; si < candidates.size(); si++) {
                                        Session s = candidates.get(si);
                                        System.out.printf("%d. %s - %s (Room: %s) (%d/%d)%n", si+1, s.getId(), s.getStartTime(), s.getRoom(), s.getCurrentEnrollment(), s.getMaxCapacity());
                                    }
                                    System.out.print("Enter session number to register participant (or 0 to skip): ");
                                    try {
                                        int sc = Integer.parseInt(scanner.nextLine()) - 1;
                                        if (sc >= 0 && sc < candidates.size()) {
                                            boolean ok = candidates.get(sc).registerParticipant(participantToEnroll.getId());
                                            if (ok) System.out.println("Participant registered into session " + candidates.get(sc).getId());
                                            else System.out.println("Could not register participant into session (maybe full or already registered).");
                                        } else {
                                            System.out.println("Skipped session registration.");
                                        }
                                    } catch (NumberFormatException nfe2) {
                                        System.out.println("Invalid input; skipped session registration.");
                                    }
                                }
                            } else {
                                System.out.println("Cancelled or invalid selection.");
                            }
                        } catch (NumberFormatException nfe) {
                            System.out.println("Invalid input.");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 0:
                        inParticipantMenu = false;
                        break;

                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
    }
    
    private static void manageInstructors(Scanner scanner) {
        boolean inInstructorMenu = true;

        while (inInstructorMenu) {
            System.out.println("\n=== Instructor Management ===");
            System.out.println("1. View All Instructors");
            System.out.println("2. Add New Instructor");
            System.out.println("3. Update Instructor Information");
            System.out.println("4. View Instructor Schedule");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option (0-4): ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        System.out.println("\n--- All Instructors ---");
                        if (instructors.isEmpty()) {
                            System.out.println("No instructors available.");
                        } else {
                            for (Instructor ins : instructors) {
                                System.out.printf("- %s (ID: %s, Specialization: %s)%n", ins.getName(), ins.getId(), ins.getSpecialty());
                            }
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 2:
                        System.out.println("\n--- Add New Instructor ---");
                        System.out.print("Enter instructor name: ");
                        String iname = scanner.nextLine();
                        System.out.print("Enter specialization: ");
                        String ispecialty = scanner.nextLine();
                        String iid = "I" + (2000 + (int)(Math.random() * 1000));
                        Instructor newInstructor = new Instructor(iid, iname, ispecialty);
                        instructors.add(newInstructor);
                        System.out.println("\nInstructor added successfully!");
                        System.out.println("Name: " + iname);
                        System.out.println("Specialization: " + ispecialty);
                        System.out.println("ID: " + iid);
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 3:
                        System.out.println("\n--- Update Instructor ---");
                        System.out.print("Enter instructor ID to update: ");
                        String updateId = scanner.nextLine();
                        Instructor toUpdate = null;
                        for (Instructor ins : instructors) {
                            if (ins.getId().equalsIgnoreCase(updateId)) { toUpdate = ins; break; }
                        }
                        if (toUpdate == null) {
                            System.out.println("Instructor not found.");
                        } else {
                            System.out.print("Enter new name (or press Enter to keep current): ");
                            String newName = scanner.nextLine();
                            System.out.print("Enter new specialization (or press Enter to keep current): ");
                            String newSpec = scanner.nextLine();
                            if (!newName.isEmpty()) toUpdate.setName(newName);
                            if (!newSpec.isEmpty()) toUpdate.setSpecialty(newSpec);
                            System.out.println("Instructor updated.");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 4:
                        System.out.println("\n--- Instructor Schedule ---");
                        System.out.print("Enter instructor ID: ");
                        String viewId = scanner.nextLine();
                        Instructor found = null;
                        for (Instructor ins : instructors) {
                            if (ins.getId().equalsIgnoreCase(viewId)) { found = ins; break; }
                        }
                        if (found == null) {
                            System.out.println("Instructor not found.");
                        } else {
                            System.out.println("\nSchedule for Instructor " + found.getName() + " (" + found.getId() + "):");
                            System.out.println("1. Java Fundamentals - Mon/Wed 10:00-12:00");
                            System.out.println("2. Advanced Java - Tue/Thu 14:00-16:00");
                            System.out.println("3. Office Hours - Fri 10:00-12:00");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 0:
                        inInstructorMenu = false;
                        break;

                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
    }
    
    private static void scheduleSessions(Scanner scanner) {
        SessionService.manageSessions(scanner, sessions, trainings, instructors, participants);
    }
    
    private static void manageCertifications(Scanner scanner) {
        boolean inCertMenu = true;

        while (inCertMenu) {
            System.out.println("\n=== Certification Management ===");
            System.out.println("1. View All Certifications");
            System.out.println("2. Issue New Certification");
            System.out.println("3. Verify Certification");
            System.out.println("4. View Certification Details");
            System.out.println("0. Back to Main Menu");
            System.out.print("\nSelect an option (0-4): ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        System.out.println("\n--- All Certifications ---");
                        for (Certification c : certificationService.listCertificates()) {
                            System.out.println(c.toString());
                        }
                        if (certificationService.listCertificates().isEmpty()) {
                            System.out.println("No certifications issued yet.");
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 2:
                        System.out.println("\n--- Issue New Certification ---");
                        System.out.print("Enter participant ID: ");
                        String participantId = scanner.nextLine();
                        System.out.print("Enter training ID: ");
                        String trainingId = scanner.nextLine();
                        System.out.println("Select certificate type:");
                        System.out.println("1. Basic");
                        System.out.println("2. Advanced");
                        System.out.println("3. Professional");
                        System.out.print("Enter choice (1-3): ");
                        String typeChoice = scanner.nextLine();
                        String type = "basic";
                        if ("2".equals(typeChoice)) type = "advanced";
                        else if ("3".equals(typeChoice)) type = "professional";
                        Certification issued = certificationService.issueCertificate(type, trainingId, participantId);
                        System.out.println("\nCertification issued successfully!");
                        System.out.println("Certification ID: " + issued.getId());
                        System.out.println("Issue Date: " + issued.getIssueDate());
                        System.out.println("Expiry Date: " + issued.getExpiryDate());
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 3:
                        System.out.println("\n--- Verify Certification ---");
                        System.out.print("Enter certification ID: ");
                        String certId = scanner.nextLine();
                        Certification cert = certificationService.findById(certId);
                        if (cert == null) {
                            System.out.println("Certification not found.");
                        } else {
                            System.out.println("\nVerification Result:");
                            System.out.println("Certification ID: " + cert.getId());
                            System.out.println("Status: " + (cert.isValid() ? "Valid" : "Expired"));
                            System.out.println("Issued To: " + cert.getParticipantId());
                            System.out.println("Training ID: " + cert.getTrainingId());
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;

                    case 4:
                        System.out.println("\n--- Certification Details ---");
                        System.out.print("Enter certification ID: ");
                        String viewId = scanner.nextLine();
                        Certification detail = certificationService.findById(viewId);
                        if (detail == null) {
                            System.out.println("Certification not found.");
                        } else {
                            System.out.println(detail.toString());
                            System.out.println("Participant ID: " + detail.getParticipantId());
                            System.out.println("Training ID: " + detail.getTrainingId());
                            System.out.println("Issue Date: " + detail.getIssueDate());
                            System.out.println("Expiry Date: " + detail.getExpiryDate());
                            System.out.println("Valid: " + detail.isValid());
                        }
                        System.out.println("Press Enter to continue...");
                        scanner.nextLine();
                        break;
                    case 0:
                        inCertMenu = false;
                        break;
                    default:
                        System.out.println("\nInvalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nPlease enter a valid number.");
            }
        }
    }
}