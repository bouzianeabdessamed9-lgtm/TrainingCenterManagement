package com.trainingcenter.exceptions;

public class InstructorNotAvailableException extends Exception {
    public InstructorNotAvailableException(String message) {
        super(message);
    }
}
