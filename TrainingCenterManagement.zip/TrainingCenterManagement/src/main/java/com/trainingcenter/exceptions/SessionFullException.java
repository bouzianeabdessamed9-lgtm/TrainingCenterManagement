package com.trainingcenter.exceptions;

public class SessionFullException extends Exception {
    public SessionFullException(String message) {
        super(message);
    }
}
