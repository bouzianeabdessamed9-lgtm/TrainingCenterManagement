package com.trainingcenter.exceptions;

public class TrainingNotFoundException extends Exception {
    public TrainingNotFoundException(String message) {
        super(message);
    }
}
